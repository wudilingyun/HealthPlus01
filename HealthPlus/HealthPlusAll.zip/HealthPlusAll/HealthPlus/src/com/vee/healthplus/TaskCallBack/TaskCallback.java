package com.vee.healthplus.TaskCallBack;

public interface  TaskCallback {
	public abstract void taskCallback(TaskResult taskResult);
}
