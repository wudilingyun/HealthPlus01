package com.vee.healthplus.TaskCallBack;

import java.util.ArrayList;
import java.util.List;

public class TaskResult {
	public List<String> titles = new ArrayList<String>();

}
