package com.vee.healthplus.common;


public interface IFragmentMsg {
	public void replaceFragment(FragmentMsg fMsg);
    public void updateHeaderTitle(String title);
}
