package com.vee.healthplus.util.user;

/**
 * Created by wangjiafeng on 13-11-14.
 */
public interface ICallBack {
	public void onChange();

	public void onCancel();
}
