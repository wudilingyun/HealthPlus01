package com.vee.healthplus.heahth_news_beans;

import java.util.List;

public class ResponseData {
	private List<Doc> docs;

	public List<Doc> getDocs() {
		return docs;
	}

	public void setDocs(List<Doc> docs) {
		this.docs = docs;
	}

}
