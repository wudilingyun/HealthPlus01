package com.vee.healthplus.heahth_news_beans;

public class Root {
  private ResponseData response;

public ResponseData getResponse() {
	return response;
}

public void setResponse(ResponseData response) {
	this.response = response;
}
	   
}
