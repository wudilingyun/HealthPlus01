package com.vee.healthplus.util.sporttrack;

import java.util.HashMap;
import java.util.List;

public interface ISensorData {

//	public HashMap<String, String> getTaskState();
//
//	public void showTaskState();
//
//	public boolean isTrack(long begintime, long endtime, int userid);
//
//	public List<TrackEntity> getTrackListByDate(long begintime, long endtime,
//			int userid);
//
//	public List<TrackEntity> getRecordById(int id, int userid);
}
